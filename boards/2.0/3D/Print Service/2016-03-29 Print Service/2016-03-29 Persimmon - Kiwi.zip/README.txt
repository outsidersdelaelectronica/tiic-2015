Samuel López Asunción
ETSI Telecomunicación - UPM B105Lab
samuel.lopez.asuncion@alumnos.upm.es

Software de diseño:		SketchUp Make 15.3
Slicer:					Cura 15.04
Perfil de impresión:	BQ Witbox 2 - PLA - Medium Quality (altura de capa = 0.2 mm)
Color preferido:		Blanco

													Tiempo			X			Y			Z

Kiwi Charger Print v1.2 - Bottom					1h 28m			82 mm		47 mm		22.5 mm
Kiwi Charger Print v1.2 - Top						1h 38m			82 mm		47 mm		25 mm
Persimmon Access Device Print v1.1 - Bottom			4h 24m			139.7 mm	109.9 mm	21 mm
Persimmon Access Device Print v1.1 - Top			1h 41m			139.7 mm	109.9 mm	19.6 mm
Persimmon Pacemaker Belt Holder v1.1				39m				50 mm		8 mm		50 mm
Persimmon Pacemaker Print v1.1 - Bottom				3h 36m			110.65 mm	109.9 mm	18.8 mm
Persimmon Pacemaker Print v1.1 - Top				1h 50m			110.65 mm	109.9 mm	15.6 mm